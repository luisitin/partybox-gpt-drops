# Measured verification

The full release validator passed for all 3,000 original candidates and the
final 600 fill + 600 most-likely prompts. The complete verbatim validator output
is in `results/release.json`; exhaustive scan evidence is in
`results/pool-similarity.json`. Previous draft measurements and known failures
remain in `verification-history/` and the original grading records.

| Check | Cases | Passed | Seed | Exact command |
| --- | ---: | ---: | --- | --- |
| Original JSON Schema, IDs, genre, 90-character limit | 3000 | 3000 | not applicable | `python3 scripts/verify.py` |
| Actual independent grade/reason coverage and input hashes | 3000 | 3000 | not applicable | `python3 scripts/verify.py` |
| Sealed original authored batch integrity | 30 | 30 | not applicable | `python3 scripts/verify.py` |
| Complete original-pool pair comparisons, two text forms and both directions | 4498500 | 4498500 | not applicable | `python3 scripts/scan_pool.py` |
| Final JSON Schema, unchanged graded text, grades 4+ in both passes | 1200 | 1200 | not applicable | `python3 scripts/verify.py` |
| Independent final-pack pair comparisons and flag resolutions | 719400 | 719400 | not applicable | `python3 scripts/verify.py` |
| Final adult-only, no-slur and literal named-reference editorial audit | 1200 | 1200 | not applicable | `python3 scripts/verify.py` |
| All original candidates' editorial confidence records | 3000 | 3000 | not applicable | `python3 scripts/verify.py` |
| Combined canonical reference buckets, cap three | 630 | 630 | not applicable | `python3 scripts/verify.py` |
| Delivered-file size limit | 164 | 164 | not applicable | `python3 scripts/checksums.py` |
| Delivered-file SHA256 integrity | 163 | 163 | not applicable | `sha256sum -c SHA256SUMS.txt` |

Independent grade coverage does not mean all candidate jokes passed the humor
rubric: 1,978 qualified at grade 4+ in both passes. Only unchanged qualifying
rows were eligible for selection. Exact-grade agreement was 1,343/3,000
(44.76666667%); keep-threshold agreement was 2,217/3,000 (73.9%). Every rejected
grade and reason remains visible. All first-author grades were sealed before
grade-free handoff to the named independent reviewers.

The final editor read all 1,200 initially selected rows plus the replacement
rows, checked actual name spans, and excluded child mascots, unsupported tags
and repeated premises. `editorial-review.json` logs checks and confidence per
selected row; `named-reference-audit.json` records canonical aggregation. The
final pack contains no selected child-mascot scene. Rejected original child
mascots remain preserved and explicitly excluded rather than silently deleted.

The original-pool scan flagged 57 pairs above 0.75 similarity and retained all
55 earlier one-direction flags. Both full wording and wording after removing
the shared most-likely prefix are compared in both argument directions using
`difflib.SequenceMatcher(..., autojunk=False)`. The symmetric `quick_ratio`
upper bound skips an exact ratio only when neither direction can exceed 0.75;
it does not sample or reduce pair coverage. Fixed right-hand string indexes
are cached; no pair result is assumed. All 12 disjoint left-index segments and
their exact counts are recorded. The complete scan took 695.593576 seconds on
this local machine. All four flags in the final pack have individual distinct-
mechanism explanations. Removed candidates and earlier curation iterations
are retained; no selected joke or its independent grade was rewritten.

These are original fictional prompts with zero nonfiction fact claims, so
factual-source pairs and source reopenings are not invented. `SOURCES.md`
documents that scope. Editorial confidence is high for two grades of 5,
medium for two grades of at least 4, and low for rejected candidates below 4.

Full packaging rerun: `npm test` runs the complete exhaustive pool scan again,
all release checks, and every manifest hash. `SHA256SUMS.txt` covers all
delivered job files except itself; its generation checks every file against
the 30,000,000-byte size limit. Hosted CI uses one read-only Ubuntu job with
a 30-minute timeout and pinned major-version `actions/*` steps. The exact
GitHub workflow run is linked in the PR after it completes.

## UNVERIFIED

- Humor and confidence are editorial judgments, not an audience playtest.
- Textual similarity cannot prove absence of every conceivable semantic
  resemblance. Individually flagged pairs and actual final curation are
  provided for maintainer review.
- The exact-head hosted CI conclusion and run link are recorded in the PR;
  local validation alone does not establish a hosted result.
- This delivery remains unmerged and requires the repository maintainer's review.
