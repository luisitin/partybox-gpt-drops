import {readFileSync,writeFileSync,mkdirSync,openSync,writeSync,closeSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {nameFilter,isAllowedName} from '/tmp/B19-root-checkpoint-20261009/jobs/B19-name-filter/dist/nameFilter.js';
import {createReference} from '/tmp/B19-root-checkpoint-20261009/jobs/B19-name-filter/tests/independent-unicode-20261009/reference.mjs';
const job='/tmp/B19-root-checkpoint-20261009/jobs/B19-name-filter',out='/tmp/B19-final-assigned-unicode-audit-20261009';
mkdirSync(out,{recursive:false});
const sha=b=>createHash('sha256').update(b).digest('hex');
const paths=[import.meta.filename,process.execPath,job+'/nameFilter.ts',job+'/dist/nameFilter.js',job+'/tests/independent-unicode-20261009/reference.mjs',job+'/tests/independent-unicode-20261009/seal.json',job+'/data/policy.json'];
const snapshot=()=>paths.map(path=>{const bytes=readFileSync(path);return{path,bytes:bytes.length,sha256:sha(bytes)};});
const before=snapshot();
assert.equal(before[2].sha256,'446bdd89b9bb6fe65dcdaa2f6c7a578111034d957aeb4a9f16cc64efba5c05a0');
assert.equal(before[3].sha256,'c50ea16d2077921bb4e0879a4804b709c1ea12aac763fc1fcfa16b35920c95b7');
assert.equal(before[4].sha256,'a93b35e3170122b2fd0a77619eff36716c3b9fc2f4c47f3bfce1971778a76e71');
assert.equal(before[5].sha256,'a8cded0ef5e4bf8da574184baabdfa57e9103c43981e8bc9019085ff0b9b1511');
const oracle=createReference(JSON.parse(readFileSync(job+'/data/policy.json','utf8')));
const templates=[c=>c,c=>'an'+c+'al',c=>'anal'+c,c=>'analysis'+c];
const excluded=/[\p{Cn}\p{Co}]/u;
const report={status:'RUNNING',startedAt:new Date().toISOString(),sourceHead:'89ea55cbb48400e6c4d112008c2e64d55ca5d3ce',checkpointHead:'b9baf363f60cffa126114c45c641035bab1288d4',unicode:process.versions.unicode,runtime:process.version,timed:false,before,seeds:[],disagreements:0,scope:'New untimed supported-weakness diagnostic: every code point outside Unicode Cn/Co, including lone surrogates, in the four original exhaustive contexts at seeds1/2/3. Cn/Co already have their complete952198-point barrier-context receipt. This diagnostic is separate from the original npm-test acceptance: no benchmark, workload, gate, source or oracle mutation; no all-context, all-language or latency claim.'};
const stream=openSync(out+'/all-disagreements.jsonl','wx');let chunk='';
try{
 for(const seed of [1,2,3]){
  const counts=templates.map(()=>({cases:0,independentAgreements:0,wrapperAgreements:0}));let points=0;
  for(let position=0;position<=0x10ffff;position++){
   const point=seed===1?position:seed===2?0x10ffff-position:(position*65537)%1114112;
   const c=String.fromCodePoint(point);if(excluded.test(c))continue;points++;
   for(let context=0;context<templates.length;context++){
    const input=templates[context](c),production=nameFilter(input),independent=oracle.nameFilter(input),allowed=isAllowedName(input),row=counts[context];
    const same=JSON.stringify(production)===JSON.stringify(independent),wrapper=allowed===production.ok;
    row.cases++;row.independentAgreements+=same?1:0;row.wrapperAgreements+=wrapper?1:0;
    if(!same||!wrapper){report.disagreements++;chunk+=JSON.stringify({seed,point,context,input,production,independent,allowed})+'\n';if(chunk.length>65536){writeSync(stream,chunk);chunk='';}}
   }
  }
  assert.equal(points,161914);report.seeds.push({seed,order:seed===1?'ascending':seed===2?'descending':'65537 permutation',points,counts,cases:counts.reduce((n,r)=>n+r.cases,0)});
  console.log(JSON.stringify({seed,points,cases:report.seeds.at(-1).cases,disagreements:report.disagreements}));
 }
 report.status=report.disagreements===0?'PASS':'FAIL';
}catch(error){report.status='FAILED_EXCEPTION';report.error={name:error.name,message:error.message,stack:error.stack};}
finally{
 if(chunk)writeSync(stream,chunk);closeSync(stream);report.after=snapshot();report.guardsUnchanged=JSON.stringify(before)===JSON.stringify(report.after);report.closedAt=new Date().toISOString();report.cases=report.seeds.reduce((n,r)=>n+r.cases,0);report.allActualFailuresRetained=true;
 if(!report.guardsUnchanged)report.status='FAIL';writeFileSync(out+'/receipt.json',JSON.stringify(report,null,2)+'\n');
}
assert.equal(report.cases,1942968);assert.equal(report.status,'PASS');console.log(JSON.stringify({status:report.status,closedAt:report.closedAt,cases:report.cases,disagreements:report.disagreements,guardsUnchanged:report.guardsUnchanged}));
