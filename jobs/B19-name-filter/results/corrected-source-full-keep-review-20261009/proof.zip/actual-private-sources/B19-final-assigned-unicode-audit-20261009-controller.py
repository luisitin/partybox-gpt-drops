from pathlib import Path
import os,sys,json,hashlib,subprocess,signal,datetime,ctypes,traceback
ROOT=Path('/tmp/B19-root-checkpoint-20261009');JOB=ROOT/'jobs/B19-name-filter'
BASE=Path('/tmp/B19-final-assigned-unicode-audit-controller-20261009')
NODE=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
DRIVER=Path('/tmp/B19-final-assigned-unicode-audit-20261009.mjs')
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def snap():
 rows={}
 for line in (JOB/'SHA256SUMS.txt').read_text().splitlines():
  digest,path=line.split('  ',1);assert sha(JOB/path)==digest,path;rows[str(JOB/path)]=digest
 for path in [JOB/'SHA256SUMS.txt',JOB/'dist/nameFilter.js',JOB/'tests/independent-unicode-20261009/reference.mjs',NODE,DRIVER,Path(__file__),Path(sys.executable)]:rows[str(path)]=sha(path)
 return rows
def write(name,x):(BASE/name).write_text(json.dumps(x,indent=2)+'\n')
BASE.mkdir(exist_ok=False);started=utc();before=snap();write('source-before.json',before)
assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
child=None;receipt={'status':'RUNNING','startedAt':started,'wallLimitSeconds':240,'scope':'One new untimed assigned-Unicode semantic audit; no original performance run, source adoption or timing gain.'};write('controller.json',receipt)
failure=None;code=None;forced=False
try:
 with (BASE/'stdout.log').open('wb') as out,(BASE/'stderr.log').open('wb') as err:
  child=subprocess.Popen([str(NODE),str(DRIVER)],cwd=JOB,stdout=out,stderr=err,start_new_session=True)
  try:code=child.wait(timeout=240)
  except subprocess.TimeoutExpired:
   forced=True;os.killpg(child.pid,signal.SIGTERM)
   try:code=child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
   raise TimeoutError('Declared240-second finite semantic diagnostic expired; retain all partial outputs')
 assert code==0,'Actual diagnostic child failed'
 d=json.loads(Path('/tmp/B19-final-assigned-unicode-audit-20261009/receipt.json').read_text());assert d['status']=='PASS' and d['cases']==1942968 and d['disagreements']==0 and d['guardsUnchanged']
 assert (BASE/'stderr.log').stat().st_size==0
except BaseException as e:failure={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()}
finally:
 if child is not None and child.poll() is None:
  forced=True;os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=5)
 remaining=[]
 if child is not None:
  for p in Path('/proc').glob('[0-9]*/stat'):
   try:
    t=p.read_text();fields=t[t.rfind(')')+2:].split()
    if int(fields[2])==child.pid and fields[0] not in ('Z','X'):remaining.append(int(p.parent.name))
   except (OSError,ValueError,IndexError):pass
 try:after=snap();write('source-after.json',after);assert after==before
 except BaseException as e:failure={'type':type(e).__name__,'message':str(e),'scope':'Source-finalization failure invalidates whole observation'}
 if remaining:failure={'type':'OwnedProcessRemains','pids':remaining}
 receipt.update(status='CLOSED_FAILED' if failure or forced else 'CLOSED_PASS',closedAt=utc(),actualExitCode=code,natural=not forced,actualRemainingGroup=remaining,failure=failure,stdoutSha256=sha(BASE/'stdout.log'),stderrSha256=sha(BASE/'stderr.log'),actualFrozenFiles=len(before))
 write('controller.json',receipt);print(json.dumps(receipt),flush=True)
sys.exit(1 if failure or forced else 0)
