import {nameFilter,isAllowedName} from '/workspace/partybox-gpt-drops-B19-finish/jobs/B19-name-filter/dist/nameFilter.js';
import {reference} from '/workspace/partybox-gpt-drops-B19-finish/jobs/B19-name-filter/dist/tests/reference.js';
import {createReference} from '/workspace/partybox-gpt-drops-B19-finish/jobs/B19-name-filter/tests/blind/reference.mjs';
import {readFileSync,writeFileSync,openSync,writeSync,closeSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root='/workspace/partybox-gpt-drops-B19-finish/jobs/B19-name-filter';
const out='/tmp/B19-unicode-scalar-differential-20261009';
mkdirSync(out,{recursive:false});
const sha=b=>createHash('sha256').update(b).digest('hex');
const paths=['nameFilter.ts','dist/nameFilter.js','dist/tests/reference.js','tests/reference.ts','tests/blind/reference.mjs','data/policy.json'];
const identities=()=>Object.fromEntries(paths.map(p=>[p,sha(readFileSync(root+'/'+p))]));
const before=identities();
assert.equal(before['nameFilter.ts'],'7817489fc1d0908a87914223a84b31c15ea7e13b3555cb4238594751616f163d');
assert.equal(before['dist/nameFilter.js'],'e4b39efbf033bef9c41788e9bf0f002cdb61ff9dbbdfa6cbfcbfda65122d2cf9');
assert.equal(before['tests/blind/reference.mjs'],'40449357a616619cc649d6b8efab2f6664a187de178511b8b0f17e28e92eea9a');
const blind=createReference(JSON.parse(readFileSync(root+'/data/policy.json','utf8')));
const label=r=>r.ok?'ok':r.reason;
const templates=[c=>c,c=>'an'+c+'al',c=>'anal'+c,c=>'analysis'+c];
const counts=templates.map(()=>({cases:0,referenceAgreements:0,blindAgreements:0,wrapperAgreements:0}));
const result={schema:'b19-exhaustive-unicode-scalar-context-differential/1',scope:'Untimed correctness supplement, all code points 0..0x10ffff including lone-surrogate input cases in four declared contexts; no native timing acceptance, gate change or player adoption.',startedAt:new Date().toISOString(),sourceHeadAtActualDiagnostic:'375d344635a689b78dc0c8bd1aa7d42f9b53c97d',publicCheckpointSameProduction:'a2f8c497b047c564e8a757f3667e7b5ca9d5f67f',sourcesBefore:before,runtime:{version:process.version,unicode:process.versions.unicode,sha256:sha(readFileSync(process.execPath))},contexts:['single code point','an + code point + al','anal + code point','analysis + code point'],counts,disagreements:0};
const stream=openSync(out+'/all-disagreements.jsonl','wx');
let chunk='';
try{
 for(let point=0;point<=0x10ffff;point++){
  const c=String.fromCodePoint(point);
  for(let context=0;context<templates.length;context++){
   const input=templates[context](c),actual=nameFilter(input),expected=reference(input),independent=blind.nameFilter(input),allowed=isAllowedName(input),a=label(actual),e=label(expected),i=label(independent),row=counts[context];
   row.cases++;row.referenceAgreements+=a===e?1:0;row.blindAgreements+=a===i?1:0;row.wrapperAgreements+=allowed===actual.ok?1:0;
   if(a!==e||a!==i||allowed!==actual.ok){
    result.disagreements++;chunk+=JSON.stringify({point,context,input,actual,expected,independent,allowed})+'\n';
    if(chunk.length>65536){writeSync(stream,chunk);chunk='';}
   }
  }
 }
 result.status=result.disagreements===0?'PASS':'FAIL';
}catch(error){result.status='FAILED_EXCEPTION';result.failure={name:error.name,message:error.message};}
finally{
 if(chunk)writeSync(stream,chunk);closeSync(stream);
 result.sourcesAfter=identities();result.sourceUnchanged=JSON.stringify(result.sourcesAfter)===JSON.stringify(before);
 result.closedAt=new Date().toISOString();result.totalCases=counts.reduce((n,r)=>n+r.cases,0);
 result.allDisagreementsRetained=true;result.originalAcceptancePassed=false;
 writeFileSync(out+'/receipt.json',JSON.stringify(result,null,2)+'\n');
}
console.log(JSON.stringify(result));
assert.equal(result.totalCases,4456448);
assert(result.sourceUnchanged);
assert.equal(result.status,'PASS');
