import copy
import datetime
import hashlib
import json
from pathlib import Path
import runpy

ROOT = Path('/workspace/partybox-gpt-drops-B19-finish')
BASE = ROOT / '.work/B19-prospective-native-profile'
OUT = Path('/tmp/B19-saved-telemetry-reader-20261009.json')
PINS = {
    'READY-retained.json': 'e0ea9cdc491376f683d10e7bf16702ae1073828873b38698016c6773ec21794a',
    'run-retained-once.py': '04cc12482213cf8a6020bacf31d96e1e8f8aed0f23bbadebf4cce88e652df3e7',
    'diagnostic-retained.mjs': '33025e91af50245999a95db5f5c07ab89decbf1b8f17cde76b7631ff9409b3b2',
    'diagnostic-retained-report.json': '15ef4faead0d2aa89681ef9ba03c8f256629207f10419bd929c7cc4fb5a15fd0',
    'diagnostic-retained.cpuprofile': '89de0fa7092d28390e59934b598ee69b760c2e8c8fb0a8e7c951a3074f137b45',
}
RECOVERY = ROOT / '.work/B19-ASCII-mapping-candidate/TIMING_READY_PATHS.json'
RECOVERY_SHA = '9494a73a1dbbb8d83eecb35eb8aa2c3a391db503b16746c9d18cacfdc7ae964d'
MISSING = {
    'jobs/B19-name-filter/dist/nameFilter.js': 'e4b39efbf033bef9c41788e9bf0f002cdb61ff9dbbdfa6cbfcbfda65122d2cf9',
    'jobs/B19-name-filter/dist/tests/reference.js': 'fb41af66df9ec5db3464ee870ed2db138903a1b7211614ab34e1344f6a1059f8',
    'jobs/B19-name-filter/data/cache/names.json': '98ea30b5406ed5abdf5587dc3d4117ad0c4f60208657eb3317fe0b6007eeedab',
    'jobs/B19-name-filter/data/cache/words.json': '458a956fc9c3c415eb44b23394d88ddf18e26fb9fd3ca116e26f6c7dae6449a3',
    'jobs/B19-name-filter/data/cache/places.json': '3e865402f14e284327d6c69b807008faef092dfcb7841322d40eaf0da9324cac',
}

def identity(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def frozen_inputs():
    found = {name: identity(BASE / name) for name in PINS}
    for name, expected in PINS.items():
        assert found[name]['sha256'] == expected, name
    found['oldRecoveryMap'] = identity(RECOVERY)
    assert found['oldRecoveryMap']['sha256'] == RECOVERY_SHA
    for name in ['retained-controller.json', 'root-retained-grant.json', 'retained-native.log']:
        found[name] = identity(BASE / name)
    found['offlineReader'] = identity(__file__)
    return found

def main():
    assert not OUT.exists(), 'Once-only offline receipt already exists'
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = frozen_inputs()
    ready = json.loads((BASE / 'READY-retained.json').read_bytes())
    original = copy.deepcopy(ready)
    report = json.loads((BASE / 'diagnostic-retained-report.json').read_bytes())
    failed = json.loads((BASE / 'retained-controller.json').read_bytes())
    old = json.loads(RECOVERY.read_bytes())
    assert failed['status'] == 'DIAGNOSTIC_FAILED'
    assert failed['afterCheckFailure'] == {'type': 'KeyError', 'message': "'jobs/B19-name-filter/dist/nameFilter.js'"}
    assert failed['exitCode'] == 0 and failed['naturalClosure'] is True
    assert failed['remainingOwnedLiveProcesses'] == []
    missing_actual = {'jobs/B19-name-filter/' + name for name in report['sourceStart'] if 'jobs/B19-name-filter/' + name not in ready['sources']}
    assert missing_actual == set(MISSING)
    recovered = {}
    for relative, expected in MISSING.items():
        path = ROOT / relative
        actual = identity(path)
        assert relative not in ready['sources']
        assert old['sourceGuards'][str(path.resolve())] == expected
        key = relative.removeprefix('jobs/B19-name-filter/')
        assert report['sourceStart'][key] == report['sourceEnd'][key] == expected
        assert actual['sha256'] == expected
        ready['sources'][relative] = actual
        recovered[relative] = actual
    # Import definitions only. The original main, native diagnostic and profiler are never called.
    original_reader = runpy.run_path(str(BASE / 'run-retained-once.py'), run_name='b19_offline_definitions_only')
    original_reader['source_check'](ready)
    result = original_reader['validate_diagnostic'](ready)
    original_reader['source_check'](ready)
    assert json.loads((BASE / 'READY-retained.json').read_bytes()) == original
    after = frozen_inputs()
    assert after == before
    output = {
        'schema': 'b19-saved-telemetry-offline-reader/1',
        'status': 'SAVED_TELEMETRY_VERIFIED_WITH_REPAIRED_OFFLINE_READER',
        'startedAt': started,
        'closedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'originalControllerStatusUnchanged': failed['status'],
        'scope': 'Saved bytes only; exactly five omitted generated dependencies recovered from a previously frozen map and actual diagnostic internal before/after hashes. No native rerun, retrospective approval, production change, acceptance or historical cause claim.',
        'originalSourceCount': len(original['sources']),
        'augmentedOfflineSourceCount': len(ready['sources']),
        'runtimeCount': len(ready['runtimes']),
        'originalPredicates': result,
        'recoveredGeneratedInputs': recovered,
        'before': before,
        'after': after,
        'originalAcceptancePassed': False,
        'historicalCauseEstablished': False,
        'clockAlignmentEstablished': False,
        'cpuSamplingIntervalUs': 100,
        'diagnosticOverOriginal50usThresholdCounts': [sum(x['timeMs'] > .05 for x in row['raw']) for row in report['reports']],
        'diagnosticMaximumCallMs': [max(x['timeMs'] for x in row['raw']) for row in report['reports']],
    }
    OUT.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({k: output[k] for k in ['status', 'startedAt', 'closedAt', 'originalControllerStatusUnchanged', 'originalSourceCount', 'augmentedOfflineSourceCount', 'runtimeCount', 'originalPredicates', 'diagnosticOverOriginal50usThresholdCounts', 'diagnosticMaximumCallMs']}))

if __name__ == '__main__':
    main()
