// PROSPECTIVE / UNEXECUTED. Instrumented diagnosis; never original acceptance.
import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance, PerformanceObserver} from 'node:perf_hooks';
import {setImmediate as immediate} from 'node:timers/promises';
import {Session} from 'node:inspector';
import {nameFilter} from '../../jobs/B19-name-filter/dist/nameFilter.js';
import {rng, pick, positive, makeObfuscations} from '../B19-ASCII-mapping-candidate/original-workload-declarations.mjs';
const here = new URL('./', import.meta.url);
const job = new URL('../../jobs/B19-name-filter/', import.meta.url);
const sha = x => createHash('sha256').update(x).digest('hex');
const guardFiles = ['nameFilter.ts','dist/nameFilter.js','tests/run.mjs','data/original-workload-policy.json','data/cache/names.json','data/cache/words.json','data/cache/places.json'];
const guards = () => Object.fromEntries(guardFiles.map(path => [path,sha(readFileSync(new URL(path,job)))]));
const sourceStart = guards();
if(sourceStart['nameFilter.ts']!=='7817489fc1d0908a87914223a84b31c15ea7e13b3555cb4238594751616f163d'||sourceStart['dist/nameFilter.js']!=='e4b39efbf033bef9c41788e9bf0f002cdb61ff9dbbdfa6cbfcbfda65122d2cf9'||sourceStart['tests/run.mjs']!=='bff0c17b62aa75d342527a8ced855678380411053476557acde61f2e1b6fbdd9')throw Error('Original source/runner drift');
const corpora=['names','words','places'].map(group=>JSON.parse(readFileSync(new URL('data/cache/'+group+'.json',job))));
if(corpora.some((rows,index)=>rows.length!==[20000,10000,2000][index])||positive.length!==48)throw Error('Original inputs drift');
const originalSamples=['42f613c210d99c21e3fde5a64a1fbb0bf1c6d0808878b753b0fc62633076dbf3','09d369654dfe8e4df51ff5fc0b0c36f9c4337726ae59b1cc7c5a56dba1223bab','7bf8a09c129b7d544ef9cb18f4622a1546f0fb085216de3c272c327e85eac098'];
const gc=[];
const observer=new PerformanceObserver(list=>{for(const e of list.getEntries())gc.push({startMs:e.startTime,durationMs:e.duration,kind:e.detail?.kind,flags:e.detail?.flags});});
observer.observe({entryTypes:['gc']});
const session=new Session();session.connect();
const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(error,value)=>error?reject(error):resolve(value)));
const reports=[];let inspectorStarted=false;
try {
 await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:100});
 const profileStartCalibration={performanceMs:performance.now(),hrtimeNs:process.hrtime.bigint().toString()};
 await post('Profiler.start');inspectorStarted=true;
 for(const seed of [1,2,3]){
  const generated=makeObfuscations(seed);
  if(generated.rows.length!==5000)throw Error('Original generator drift');
  const inputs=[...positive,...generated.rows.map(x=>x.input),...corpora.flat().map(x=>x.name)];
  const r=rng(seed^0x1234abcd);const sample=Array.from({length:10000},()=>pick(r,inputs));
  const sampleSha256=sha(JSON.stringify(sample));if(sampleSha256!==originalSamples[seed-1])throw Error('Original sample drift');
  let sink=0;const cpuStart=process.cpuUsage();
  // Original ten full sample rounds = 100000 warmup calls; no extra settling.
  for(let round=0;round<10;round++)for(const s of sample)sink+=nameFilter(s).ok?1:0;
  const times=new Float64Array(sample.length),starts=new Float64Array(sample.length),ends=new Float64Array(sample.length);
  let index=0;const start=performance.now();
  // Additional endpoint storage and active native instrumentation are declared changes.
  for(const s of sample){const t=performance.now();sink+=nameFilter(s).ok?1:0;const end=performance.now();times[index]=end-t;starts[index]=t;ends[index]=end;index++;}
  const end=performance.now();const cpuUsed=process.cpuUsage(cpuStart);
  const raw=sample.map((input,index)=>({index,input,startMs:starts[index],endMs:ends[index],timeMs:times[index]}));
  reports.push({seed,sampleSha256,inputCount:inputs.length,warmupCalls:100000,calls:10000,measurementStartMs:start,measurementEndMs:end,sink,cpuUsed,raw});
 }
 const profileStopCalibration={performanceMs:performance.now(),hrtimeNs:process.hrtime.bigint().toString()};
 const {profile}=await post('Profiler.stop');inspectorStarted=false;
 await immediate();await immediate();observer.disconnect();
 writeFileSync(new URL('native-profile.cpuprofile',here),JSON.stringify(profile)+'\n');
 const sourceEnd=guards();if(JSON.stringify(sourceStart)!==JSON.stringify(sourceEnd))throw Error('Original source mutated');
 const report={kind:'prospective-instrumented-diagnostic-NOT-ACCEPTANCE',actualClosedUtc:new Date().toISOString(),node:process.version,unicode:process.versions.unicode,sourceStart,sourceEnd,reports,gc,profileStartCalibration,profileStopCalibration,profileStartTimeUs:profile.startTime,profileEndTimeUs:profile.endTime,noBaselineCandidateComparison:true,noAcceptanceOrGainClaim:true,limitations:['This is a newly instrumented observation, not an unchanged original full check, a retry for a pass, or a reproduction of historical timestamps.','Native 100us CPU sampling, GC observation, extra endpoint-array writes and lack of preceding full-suite allocations change execution conditions. No causal conclusion about any earlier uninstrumented failure is permitted.','CPU-profile clock alignment must be established from actual calibration; raw native times remain separate until then. GC overlap is association only.','All30000 raw observations and every GC event are retained. No outlier filtering or timing-gate waiver.']};
 writeFileSync(new URL('diagnostic-report.json',here),JSON.stringify(report,null,2)+'\n');
} finally {
 observer.disconnect();
 if(inspectorStarted){try{await post('Profiler.stop');}catch{}}
 session.disconnect();
}
