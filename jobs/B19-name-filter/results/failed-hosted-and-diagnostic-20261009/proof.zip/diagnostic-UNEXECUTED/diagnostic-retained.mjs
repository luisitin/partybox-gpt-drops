// Prospective instrumented diagnosis. Never the original acceptance check.
import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {performance, PerformanceObserver} from 'node:perf_hooks';
import {setImmediate as immediate} from 'node:timers/promises';
import {Session} from 'node:inspector';
import {nameFilter} from '../../jobs/B19-name-filter/dist/nameFilter.js';
import {rng, pick, positive, makeObfuscations} from '../B19-ASCII-mapping-candidate/original-workload-declarations.mjs';

const here = new URL('./', import.meta.url);
const job = new URL('../../jobs/B19-name-filter/', import.meta.url);
const sha = value => createHash('sha256').update(value).digest('hex');
const guardFiles = ['nameFilter.ts','dist/nameFilter.js','tests/run.mjs','data/policy.json','data/original-workload-policy.json','data/cache/names.json','data/cache/words.json','data/cache/places.json','dist/tests/reference.js','tests/blind/reference.mjs'];
const guards = () => Object.fromEntries(guardFiles.map(path => [path,sha(readFileSync(new URL(path,job)))]));
const sampleHashes = ['42f613c210d99c21e3fde5a64a1fbb0bf1c6d0808878b753b0fc62633076dbf3','09d369654dfe8e4df51ff5fc0b0c36f9c4337726ae59b1cc7c5a56dba1223bab','7bf8a09c129b7d544ef9cb18f4622a1546f0fb085216de3c272c327e85eac098'];
const report = {
  kind:'prospective-instrumented-diagnostic-NOT-ACCEPTANCE',status:'PREPARING',actualStartedUtc:new Date().toISOString(),node:process.version,unicode:process.versions.unicode,
  reports:[],gc:[],failures:[],profileSaved:false,sourceStart:null,sourceEnd:null,
  noOriginalAcceptanceRun:true,noBaselineCandidateComparison:true,noAcceptanceOrGainClaim:true,
  limitations:[
    'New CPU sampling, GC observation and endpoint writes change execution conditions. No cause of any historical failure is established.',
    'The verbatim declarations import eagerly constructs oracle-boundary inputs before profiling; preceding full-suite allocations are absent.',
    'Exactly the original 100000 warmup calls per seed remain; no added settling or exclusions. All 30000 original sampled inputs and every completed measurement are retained, including failures.',
    'A 100us CPU sampling interval cannot resolve every individual 50us event. CPU usage is process-wide, whereas the CPU profile describes its sampled thread.',
    'Performance/hrtime/inspector clocks remain separate raw values with bracketing calibrations. No common epoch or clock alignment is assumed.',
    'GC entries are all observed and drained records, not proof that every actual GC was observable. Even a calibrated overlap would show association only.',
    'This diagnostic cannot waive the original 0.05ms gate, pass the original full suite or justify adopting an optimization.'
  ]
};
let session,observer,inspectorStarted=false,exitCode=0;
const persist = () => writeFileSync(new URL('diagnostic-retained-report.json',here),JSON.stringify(report,null,2)+'\n');
const failure = (stage,error) => {exitCode=1;report.failures.push({stage,type:error?.name??'Error',message:String(error?.message??error),stack:String(error?.stack??'')});};
const collect = entries => {for(const e of entries)report.gc.push({startMs:e.startTime,durationMs:e.duration,kind:e.detail?.kind,flags:e.detail?.flags});};
const drain = () => {if(observer)collect(observer.takeRecords());};
const calibration = () => {const performanceBeforeMs=performance.now();const hrtimeNs=process.hrtime.bigint().toString();const performanceAfterMs=performance.now();return {performanceBeforeMs,hrtimeNs,performanceAfterMs};};
const post = (method,params={}) => new Promise((resolve,reject)=>session.post(method,params,(error,value)=>error?reject(error):resolve(value)));
async function stopAndSave(stage){
  if(!inspectorStarted)return;
  report.profileStopBefore=calibration();
  try{
    const {profile}=await post('Profiler.stop');inspectorStarted=false;report.profileStopAfter=calibration();
    const raw=JSON.stringify(profile)+'\n';writeFileSync(new URL('diagnostic-retained.cpuprofile',here),raw);
    report.profileSaved=true;report.profileSha256=sha(raw);report.profileStartTimeUs=profile.startTime;report.profileEndTimeUs=profile.endTime;
  }catch(error){failure(stage,error);}
}
try{
  report.sourceStart=guards();persist();
  if(report.sourceStart['nameFilter.ts']!=='7817489fc1d0908a87914223a84b31c15ea7e13b3555cb4238594751616f163d'||report.sourceStart['dist/nameFilter.js']!=='e4b39efbf033bef9c41788e9bf0f002cdb61ff9dbbdfa6cbfcbfda65122d2cf9'||report.sourceStart['tests/run.mjs']!=='bff0c17b62aa75d342527a8ced855678380411053476557acde61f2e1b6fbdd9')throw Error('Original source/runner drift');
  const corpora=['names','words','places'].map(group=>JSON.parse(readFileSync(new URL('data/cache/'+group+'.json',job))));
  report.corpusLengths=corpora.map(rows=>rows.length);report.positiveCount=positive.length;persist();
  if(corpora.some((rows,index)=>rows.length!==[20000,10000,2000][index])||positive.length!==48)throw Error('Original inputs drift');
  observer=new PerformanceObserver(list=>collect(list.getEntries()));observer.observe({entryTypes:['gc']});
  session=new Session();session.connect();await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:100});
  report.profileStartBefore=calibration();await post('Profiler.start');inspectorStarted=true;report.profileStartAfter=calibration();report.status='RUNNING';persist();
  for(const seed of [1,2,3]){
    const generated=makeObfuscations(seed);
    const inputs=[...positive,...generated.rows.map(x=>x.input),...corpora.flat().map(x=>x.name)];
    const r=rng(seed^0x1234abcd);const sample=Array.from({length:10000},()=>pick(r,inputs));
    const row={seed,sampleSha256:sha(JSON.stringify(sample)),inputCount:inputs.length,generatedCount:generated.rows.length,warmupCalls:0,completedCalls:0,status:'PREPARED',raw:sample.map((input,index)=>({index,input,startMs:null,endMs:null,timeMs:null,status:'NOT_STARTED'}))};
    report.reports.push(row);drain();persist();
    if(generated.rows.length!==5000||row.inputCount!==37048||row.sampleSha256!==sampleHashes[seed-1])throw Error('Original sample drift');
    let sink=0;const cpuStart=process.cpuUsage();row.status='WARMUP';
    try{
      for(let round=0;round<10;round++)for(const s of sample){sink+=nameFilter(s).ok?1:0;row.warmupCalls++;}
      row.status='MEASURING';row.measurementStartMs=performance.now();
      for(let index=0;index<sample.length;index++){
        const raw=row.raw[index];raw.status='STARTED';const start=performance.now();
        try{sink+=nameFilter(sample[index]).ok?1:0;const end=performance.now();raw.startMs=start;raw.endMs=end;raw.timeMs=end-start;raw.status='COMPLETED';row.completedCalls++;}
        catch(error){const end=performance.now();raw.startMs=start;raw.endMs=end;raw.timeMs=end-start;raw.status='THREW';throw error;}
      }
      row.status='COMPLETED';
    }finally{row.measurementEndMs=performance.now();row.sink=sink;row.cpuUsed=process.cpuUsage(cpuStart);drain();persist();}
    if(row.warmupCalls!==100000||row.completedCalls!==10000)throw Error('Incomplete original workload');
    if(row.raw.some(x=>!Number.isFinite(x.startMs)||!Number.isFinite(x.endMs)||!Number.isFinite(x.timeMs)||x.timeMs<0||Math.abs(x.timeMs-(x.endMs-x.startMs))>1e-12))throw Error('Raw diagnostic clock failure');
  }
  await stopAndSave('normal-profiler-stop');
}catch(error){failure('diagnostic',error);try{drain();persist();}catch(flushError){failure('failure-persist',flushError);}}
finally{
  try{await stopAndSave('finally-profiler-stop');}catch(error){failure('finally-stop',error);}
  try{await immediate();await immediate();drain();}catch(error){failure('observer-drain',error);}
  try{observer?.disconnect();}catch(error){failure('observer-disconnect',error);}
  try{session?.disconnect();}catch(error){failure('session-disconnect',error);}
  try{report.sourceEnd=guards();if(JSON.stringify(report.sourceStart)!==JSON.stringify(report.sourceEnd))throw Error('Original source changed');}catch(error){failure('source-end',error);}
  report.allCompletedMeasurementsRetained=report.reports.every(row=>row.raw.filter(x=>x.status==='COMPLETED').length===row.completedCalls);
  report.actualClosedUtc=new Date().toISOString();report.status=exitCode===0&&report.profileSaved?'DIAGNOSTIC_COMPLETED':'DIAGNOSTIC_FAILED';
  if(report.status!=='DIAGNOSTIC_COMPLETED')exitCode=1;
  try{persist();}catch(error){failure('final-persist',error);report.status='DIAGNOSTIC_FAILED';process.stderr.write(JSON.stringify({status:'DIAGNOSTIC_FAILED',stage:'final-persist',rawPersistence:'INCOMPLETE_OR_UNKNOWN',errorType:error?.name??'Error'})+'\n');}
}
console.log(JSON.stringify({status:report.status,completedCalls:report.reports.reduce((n,row)=>n+row.completedCalls,0),observedGCEntries:report.gc.length,profileSaved:report.profileSaved,actualClosedUtc:report.actualClosedUtc,noAcceptanceOrGainClaim:true}));
process.exitCode=exitCode;
