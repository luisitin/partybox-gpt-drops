import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
READY = BASE / 'READY-retained.json'
GRANT = BASE / 'root-retained-grant.json'
RECEIPT = BASE / 'retained-controller.json'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    path = Path(path).resolve()
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest()}

def live_group(group):
    found = []
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            f = (p/'stat').read_text().rsplit(')', 1)[1].split()
            if f[0] not in ['Z', 'X'] and int(f[2]) == group:
                found.append(int(p.name))
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    return found

def send(group, sig):
    try:
        os.killpg(group, sig)
    except ProcessLookupError:
        pass

def source_check(ready):
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == ready['sourceHead']
    for expected in ready['sources'].values():
        assert identity(expected['path']) == expected, expected['path']
    for expected in ready['runtimes'].values():
        assert identity(expected['path']) == expected, expected['path']

def validate_diagnostic(ready):
    report_path=BASE/'diagnostic-retained-report.json'
    profile_path=BASE/'diagnostic-retained.cpuprofile'
    assert report_path.exists() and profile_path.exists(), 'Missing raw diagnostic/profile'
    report=json.loads(report_path.read_text())
    profile=json.loads(profile_path.read_text())
    assert report['kind']=='prospective-instrumented-diagnostic-NOT-ACCEPTANCE'
    assert report['status']=='DIAGNOSTIC_COMPLETED' and report['failures']==[] and report['profileSaved'] is True
    assert report['noOriginalAcceptanceRun'] is True and report['noAcceptanceOrGainClaim'] is True
    assert report['sourceStart']==report['sourceEnd']
    for relative,expected in report['sourceStart'].items():
        assert ready['sources']['jobs/B19-name-filter/'+relative]['sha256']==expected
    assert report['positiveCount']==48 and report['corpusLengths']==[20000,10000,2000]
    assert [row['seed']for row in report['reports']]==[1,2,3]
    for row,sample_hash,sink in zip(report['reports'],ready['sampleSha256'],ready['expectedSinks']):
        assert row['status']=='COMPLETED' and row['generatedCount']==5000 and row['inputCount']==37048
        assert row['warmupCalls']==100000 and row['completedCalls']==10000 and row['sink']==sink
        raw=row['raw'];assert len(raw)==10000
        assert [x['index']for x in raw]==list(range(10000))
        actual_input_bytes=json.dumps([x['input']for x in raw],ensure_ascii=False,separators=(',',':')).encode()
        assert hashlib.sha256(actual_input_bytes).hexdigest()==row['sampleSha256']==sample_hash
        for item in raw:
            assert item['status']=='COMPLETED'
            assert all(isinstance(item[key],(int,float)) and math.isfinite(item[key]) for key in ['startMs','endMs','timeMs'])
            assert item['timeMs']>=0 and abs(item['timeMs']-(item['endMs']-item['startMs']))<1e-12
        assert all(raw[i]['endMs']<=raw[i+1]['startMs'] for i in range(len(raw)-1))
    assert report['allCompletedMeasurementsRetained'] is True
    assert identity(profile_path)['sha256']==report['profileSha256']
    assert profile['startTime']==report['profileStartTimeUs'] and profile['endTime']==report['profileEndTimeUs']
    assert profile['endTime']>=profile['startTime']
    assert len(profile.get('samples',[]))==len(profile.get('timeDeltas',[]))
    ids=[node['id']for node in profile['nodes']];assert len(ids)==len(set(ids))
    assert all(sample in ids for sample in profile.get('samples',[]))
    for name in ['profileStartBefore','profileStartAfter','profileStopBefore','profileStopAfter']:
        c=report[name];assert c['performanceBeforeMs']<=c['performanceAfterMs'] and int(c['hrtimeNs'])>0
    for item in report['gc']:
        assert math.isfinite(item['startMs']) and math.isfinite(item['durationMs']) and item['durationMs']>=0
    return {'status':'DIAGNOSTIC_STRUCTURE_VERIFIED','rawSamples':30000,'sourceHashes':len(report['sourceStart']),'cpuSamples':len(profile.get('samples',[])),'observedGCEntries':len(report['gc']),'historicalCauseEstablished':False,'originalAcceptancePassed':False}

def main():
    ready_identity = identity(READY)
    controller_identity = identity(__file__)
    ready = json.loads(READY.read_text())
    grant = json.loads(GRANT.read_text())
    assert grant['root'] == '/root' and grant['readySha256'] == ready_identity['sha256']
    assert grant['controllerSha256'] == controller_identity['sha256']
    assert grant['sourceHead'] == ready['sourceHead'] and grant['independentStaticReviewPassed'] is True
    assert not RECEIPT.exists(), 'Once-only receipt already exists'
    assert not (BASE/'diagnostic-retained-report.json').exists()
    assert not (BASE/'diagnostic-retained.cpuprofile').exists()
    source_check(ready)
    record = {'schema':'b19-prospective-instrumented-diagnostic-controller/1','status':'STARTED','startedAt':utc(),'ready':ready_identity,'controller':controller_identity,'rootGrant':identity(GRANT),'scope':'Instrumented diagnosis only, no original acceptance rerun/gate waiver/production adoption/historical cause or gain claim','naturalClosure':False,'remainingOwnedLiveProcesses':[]}
    def save():
        RECEIPT.write_text(json.dumps(record,indent=2)+'\n')
    save()
    child = None
    code = None
    try:
        with (BASE/'retained-native.log').open('w') as log:
            child = subprocess.Popen([ready['runtimes']['node']['path'],str(BASE/'diagnostic-retained.mjs')],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            record['childPid'] = child.pid
            save()
            code = child.wait(timeout=ready['maximumChildSeconds'])
            record['naturalClosure'] = True
    except BaseException as error:
        record['failure'] = {'type':type(error).__name__,'message':str(error)}
    finally:
        if child is not None:
            if child.poll() is None or live_group(child.pid):
                record['naturalClosure'] = False
                record['exceptionalCleanup'] = True
                send(child.pid,signal.SIGTERM)
            try:
                code = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                record['naturalClosure'] = False
                record['exceptionalCleanup'] = True
                send(child.pid,signal.SIGKILL)
                code = child.wait(timeout=5)
            deadline = time.monotonic()+2
            while live_group(child.pid) and time.monotonic()<deadline:
                time.sleep(0.025)
            if live_group(child.pid):
                record['naturalClosure'] = False
                record['exceptionalCleanup'] = True
                send(child.pid,signal.SIGKILL)
                deadline = time.monotonic()+2
                while live_group(child.pid) and time.monotonic()<deadline:
                    time.sleep(0.025)
            record['remainingOwnedLiveProcesses'] = live_group(child.pid)
            record['childClosedAt'] = utc()
            assert not record['remainingOwnedLiveProcesses'], 'Owned group live; no release'
        record['exitCode'] = code
        record['log'] = identity(BASE/'retained-native.log') if (BASE/'retained-native.log').exists() else None
        for name in ['diagnostic-retained-report.json','diagnostic-retained.cpuprofile']:
            p=BASE/name
            if p.exists():record[name] = identity(p)
        record['afterChecksPassed'] = False
        try:
            source_check(ready)
            assert identity(READY)==ready_identity and identity(__file__)==controller_identity
            record['diagnosticValidation']=validate_diagnostic(ready)
            record['afterChecksPassed'] = True
        except BaseException as error:
            record['afterCheckFailure'] = {'type':type(error).__name__,'message':str(error)}
        record['closedAt'] = utc()
        record['status'] = 'DIAGNOSTIC_CLOSED' if code==0 and record['naturalClosure'] and record['afterChecksPassed'] and not record.get('failure') else 'DIAGNOSTIC_FAILED'
        save()
        print(json.dumps({k:record[k] for k in ['status','startedAt','closedAt','exitCode','naturalClosure','afterChecksPassed','remainingOwnedLiveProcesses']}),flush=True)
    return 0 if record['status']=='DIAGNOSTIC_CLOSED' else 1

if __name__=='__main__':
    raise SystemExit(main())
