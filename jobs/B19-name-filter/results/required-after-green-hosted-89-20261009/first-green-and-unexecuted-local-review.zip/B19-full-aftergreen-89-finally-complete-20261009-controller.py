from pathlib import Path
import os,sys,stat,json,hashlib,datetime,subprocess,signal,time,shutil

ROOT=Path('/tmp/B19-root-checkpoint-20261009')
JOB=ROOT/'jobs/B19-name-filter'
BASE=Path('/tmp/B19-full-aftergreen-89-finally-complete-20261009')
HEAD='89ea55cbb48400e6c4d112008c2e64d55ca5d3ce'
SELF=Path(__file__).resolve()
READY=BASE/'READY.json'
GRANT=BASE/'root-first-grant.json'
MANIFEST=BASE/'complete-inputs.json'
RECEIPT=BASE/'first-original-full-receipt.json'
LOG=BASE/'first-original-full.log'
CAPTURE=BASE/'retained-actual-first-reports'
NODE=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
PYTHON=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')
NPM=Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/lib/node_modules/npm')
GIT=Path('/usr/local/bin/git')
SHELL=Path('/bin/sh')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def file_identity(path):
 p=Path(path);raw=p.read_bytes();return {'path':str(p),'resolved':str(p.resolve(strict=True)),'bytes':len(raw),'sha256':sha(raw)}
def installed_inventory(root):
 root=Path(root);rows=[];pending=[(root,())]
 while pending:
  path,ancestors=pending.pop();info=path.lstat();resolved=path.resolve(strict=True)
  row={'path':str(path),'resolved':str(resolved),'device':info.st_dev,'inode':info.st_ino,'mode':info.st_mode,'link':os.readlink(path) if path.is_symlink() else None}
  if resolved.is_dir():
   if str(resolved) in ancestors:raise AssertionError('Installed directory cycle '+str(path))
   row['kind']='directory';rows.append(row)
   for child in sorted(path.iterdir(),key=lambda p:p.name,reverse=True):pending.append((child,ancestors+(str(resolved),)))
  else:
   assert resolved.is_file(),'Non-file installed dependency '+str(path)
   row.update(file_identity(path));row['kind']='file';rows.append(row)
  assert len(rows)<50000,'Unexpected installed dependency expansion'
 return sorted(rows,key=lambda row:row['path'])
def source_paths_and_truth():
 actual=subprocess.check_output([str(GIT),'rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert actual==HEAD
 tree=subprocess.check_output([str(GIT),'ls-tree','-rz',HEAD,'--','jobs/B19-name-filter','.github/workflows/B19.yml'],cwd=ROOT)
 selections=[]
 for entry in tree.split(b'\0'):
  if not entry:continue
  metadata,name=entry.split(b'\t',1);mode,kind,oid=metadata.split();assert kind==b'blob' and mode in (b'100644',b'100755')
  selections.append((name.decode(),oid.decode()))
 assert len(selections)==1279,len(selections)
 command=subprocess.run([str(GIT),'cat-file','--batch'],cwd=ROOT,input=('\n'.join(oid for _,oid in selections)+'\n').encode(),capture_output=True,timeout=60)
 assert command.returncode==0,'Immutable Git input read failed'
 content=command.stdout;offset=0;rows=[]
 for relative,oid in selections:
  end=content.index(b'\n',offset);header=content[offset:end].split();assert header[0].decode()==oid and header[1]==b'blob';size=int(header[2]);offset=end+1
  git_bytes=content[offset:offset+size];offset+=size;assert content[offset:offset+1]==b'\n';offset+=1
  actual_bytes=(ROOT/relative).read_bytes();assert git_bytes==actual_bytes,'Current file differs from frozen Git '+relative
  rows.append(file_identity(ROOT/relative))
 assert offset==len(content)
 return rows
def complete_inputs():
 return {'head':HEAD,'source':source_paths_and_truth(),'generated':sorted([file_identity(p) for folder in [JOB/'dist',JOB/'data/cache'] for p in folder.rglob('*') if p.is_file()],key=lambda r:r['path']),'installed':[{'root':str(p),'entries':installed_inventory(p)} for p in [JOB/'node_modules',NPM]],'runtime':[file_identity(p) for p in [NODE,PYTHON,GIT,SHELL,Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/npm'),Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3'),Path('/usr/bin/env')]],'self':file_identity(SELF),'environmentPATH':os.environ.get('PATH','')}
def owned_processes(group):
 rows=[]
 for path in Path('/proc').iterdir():
  if not path.name.isdigit():continue
  try:
   raw=(path/'stat').read_text();tail=raw[raw.rfind(')')+2:].split();state=tail[0]
   if state in ('Z','X') or int(tail[2])!=group:continue
   rows.append({'pid':int(path.name),'state':state,'group':int(tail[2])})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
def close_owned(child):
 if child is None:return []
 if child.poll() is None:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:child.wait(timeout=5)
  except subprocess.TimeoutExpired:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait(timeout=10)
 leftovers=owned_processes(child.pid)
 if leftovers:
  try:os.killpg(child.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  deadline=time.monotonic()+3
  while owned_processes(child.pid) and time.monotonic()<deadline:time.sleep(0.02)
  if owned_processes(child.pid):
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
 return owned_processes(child.pid)
if len(sys.argv)==2 and sys.argv[1]=='--prepare':
 assert not BASE.exists();BASE.mkdir();inputs=complete_inputs();save(MANIFEST,inputs)
 ready={'scope':'required-original-full-once-after-accepted-green-89','sourceHead':HEAD,'preparedAt':now(),'controller':file_identity(SELF),'manifest':file_identity(MANIFEST),'acceptedHostedReceipt':file_identity(Path('/tmp/B19-official-89-20261009/independent-hosted-validation.json')),'command':[str(NODE),str(NPM/'bin/npm-cli.js'),'test'],'workingDirectory':str(JOB),'timeoutSeconds':180,'onceOutputs':[str(RECEIPT),str(LOG),str(CAPTURE)],'grantPath':str(GRANT),'requiredOriginalBenchmark':'Every original literal observation/warmup/seed/sink/sample/mutation remains unchanged; all actual outcomes retained.','generatedPathScope':'Every actual file in dist and data/cache. Rebuilding may change file metadata, but all complete input bytes must remain identical.','installedPathScope':'Every file, directory and symlink alias reachable from the actual job node_modules root and full runtime npm package, including target bytes and stable alias identities.'}
 save(READY,ready);print(json.dumps({'status':'READY_UNEXECUTED','ready':file_identity(READY),'sourceInputs':len(inputs['source']),'generatedInputs':len(inputs['generated']),'installedEntries':sum(len(i['entries']) for i in inputs['installed']),'runtimeInputs':len(inputs['runtime'])}));sys.exit(0)
assert not any(p.exists() for p in [RECEIPT,LOG,CAPTURE]),'First-only original full outputs already exist'
ready=json.loads(READY.read_text());expected=json.loads(MANIFEST.read_text());grant=json.loads(GRANT.read_text())
assert ready['scope']==grant['scope']=='required-original-full-once-after-accepted-green-89'
assert ready['sourceHead']==HEAD and ready['controller']==file_identity(SELF) and ready['manifest']==file_identity(MANIFEST)
assert grant['ready']==file_identity(READY) and grant['controller']==file_identity(SELF) and grant['manifest']==file_identity(MANIFEST)
assert grant['issuer']=='root' and grant['allOwnersZeroConfirmed'] and grant['liveProcessAudit']==[]
assert grant['rootRuntime']==file_identity(PYTHON) and grant['sourceHead']==HEAD
assert grant['ownerCount']==6 and len(grant['ownerAcknowledgements'])==6 and len({row['owner'] for row in grant['ownerAcknowledgements']})==6
issued=datetime.datetime.fromisoformat(grant['issuedAt']);age=(datetime.datetime.now(datetime.timezone.utc)-issued).total_seconds();assert 0<=age<=120
assert ready['acceptedHostedReceipt']==file_identity('/tmp/B19-official-89-20261009/independent-hosted-validation.json')
accepted=json.loads(Path(ready['acceptedHostedReceipt']['path']).read_text());assert accepted['head']==HEAD and accepted['literalAcceptancePassed'] and accepted['checksPassed']==6497
assert complete_inputs()==expected,'Full source/generated/dependency/runtime/self input mismatch before launch'
receipt={'status':'RUNNING','startedAt':now(),'head':HEAD,'scope':ready['scope'],'ready':file_identity(READY),'controller':file_identity(SELF),'manifest':file_identity(MANIFEST),'masterGrant':file_identity(GRANT),'command':ready['command'],'timeoutSeconds':180,'beforeAllCompleteInputsMatch':True,'requiredOldSource13_5_10':'Historical immutable failure; this corrected source is a new genuine three-control change, not an unchanged luck retry.'}
with RECEIPT.open('x') as stream:stream.write(json.dumps(receipt,indent=2)+'\n')
child=None;failed=None
try:
 with LOG.open('xb') as output:
  child=subprocess.Popen(ready['command'],cwd=JOB,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  receipt['childPID']=child.pid;receipt['childStartedAt']=now();save(RECEIPT,receipt)
  receipt['exitCode']=child.wait(timeout=180);receipt['childNaturallyClosedAt']=now()
 leftovers=close_owned(child);assert not leftovers,'Owned child group remained live'
 assert (JOB/'reports/latest/summary.json').is_file(),'No complete original report'
 shutil.copytree(JOB/'reports/latest',CAPTURE)
 receipt['actualReports']=[file_identity(p) for p in sorted(CAPTURE.rglob('*')) if p.is_file()]
 summary=json.loads((CAPTURE/'summary.json').read_text());receipt['suites']=len(summary['suites']);receipt['failures']=summary['failures'];receipt['literalBenchmarks']=[json.loads((CAPTURE/f'benchmark-seed{seed}.json').read_text()) for seed in [1,2,3]]
 assert summary['mode']=='full' and len(summary['suites'])==109,'Original full suite inventory incomplete'
 assert summary['sourceSha256']=='446bdd89b9bb6fe65dcdaa2f6c7a578111034d957aeb4a9f16cc64efba5c05a0'
 for seed in [1,2,3]:
  original=json.loads((CAPTURE/f'mutations-seed{seed}.json').read_text());additional=json.loads((CAPTURE/f'unicode-mutations-seed{seed}.json').read_text())
  assert len(original)==25 and all(x['killed'] and x['cases']==43830 and x['excludedBaselineFailures']==0 for x in original)
  assert len(additional)==4 and all(x['killed'] and x['cases']==30856 for x in additional)
 receipt['afterAllCompleteInputsMatch']=complete_inputs()==expected;assert receipt['afterAllCompleteInputsMatch'],'Full inputs changed after original full'
 receipt['status']='PASS' if receipt['exitCode']==0 and not summary['failures'] else 'FAIL'
except BaseException as error:
 failed=error;receipt['status']='FAIL';receipt['error']={'type':type(error).__name__,'message':str(error)}
finally:
 receipt['finalizationErrors']=[]
 def final_phase(label,operation):
  try:return operation()
  except BaseException as error:
   receipt['finalizationErrors'].append({'phase':label,'type':type(error).__name__,'message':str(error)})
   receipt['status']='FAIL'
   return None
 leftovers=final_phase('owned-group-final-reaping',lambda:close_owned(child))
 receipt['ownedGroupsFinally']=leftovers if isinstance(leftovers,list) else ['UNKNOWN_AFTER_REAP_FAILURE']
 # Each remaining phase executes even when a preceding cleanup/retention phase
 # fails. A failed finalizer never leaves an accepted RUNNING/PASS outcome.
 def final_input_check():
  actual=complete_inputs()
  receipt['afterAllCompleteInputsMatch']=actual==expected
  if actual!=expected:
   save(BASE/'actual-final-inputs-on-mismatch.json',actual)
   raise AssertionError('Complete original source/generated/dependency/runtime/self inputs changed')
 final_phase('mandatory-complete-inputs-after-any-outcome',final_input_check)
 def final_retention():
  source=JOB/'reports/latest'
  if source.exists():
   shutil.copytree(source,CAPTURE,dirs_exist_ok=True)
   originals=sorted(p for p in source.rglob('*') if p.is_file())
   copied=sorted(p for p in CAPTURE.rglob('*') if p.is_file())
   assert [str(p.relative_to(source)) for p in originals]==[str(p.relative_to(CAPTURE)) for p in copied],'Partial original reports inventory'
   for original in originals:
    assert original.read_bytes()==(CAPTURE/original.relative_to(source)).read_bytes(),'Partial original report bytes'
   receipt['actualReports']=[file_identity(p) for p in copied]
   receipt['allActualReportsRetainedWithByteReadback']=True
  else:
   raise AssertionError('Original report folder unavailable after first attempt')
 final_phase('complete-original-raw-report-retention',final_retention)
 def final_log_check():
  if LOG.exists():receipt['actualFullLog']=file_identity(LOG)
  else:raise AssertionError('Original actual log missing')
 final_phase('actual-full-log-final-identity',final_log_check)
 if receipt['ownedGroupsFinally'] or receipt['finalizationErrors'] or not receipt.get('afterAllCompleteInputsMatch') or not receipt.get('allActualReportsRetainedWithByteReadback'):
  receipt['status']='FAIL'
 receipt['wholeControllerNaturallyClosedAt']=now()
 # The /tmp first receipt is preserved whenever writable; if saving itself
 # fails, stdout carries the complete final receipt so it is recoverable.
 final_phase('final-receipt-save',lambda:save(RECEIPT,receipt))
 if receipt['finalizationErrors']:
  receipt['status']='FAIL'
  final_phase('final-failure-receipt-save',lambda:save(RECEIPT,receipt))
 print(json.dumps({'status':receipt['status'],'exitCode':receipt.get('exitCode'),'wholeControllerNaturallyClosedAt':receipt['wholeControllerNaturallyClosedAt'],'ownedGroupsFinally':receipt['ownedGroupsFinally'],'suites':receipt.get('suites'),'failedSuites':[{'name':r['name'],'seed':r.get('seed'),'cases':r['cases'],'passed':r['passed']} for r in receipt.get('failures',[])],'error':receipt.get('error'),'finalizationErrors':receipt['finalizationErrors'],'afterAllCompleteInputsMatch':receipt.get('afterAllCompleteInputsMatch'),'allActualReportsRetainedWithByteReadback':receipt.get('allActualReportsRetainedWithByteReadback')}))
 if receipt['finalizationErrors']:print('FULL_RECOVERABLE_FINAL_RECEIPT '+json.dumps(receipt))
sys.exit(0 if receipt['status']=='PASS' and not receipt['ownedGroupsFinally'] else 1)
