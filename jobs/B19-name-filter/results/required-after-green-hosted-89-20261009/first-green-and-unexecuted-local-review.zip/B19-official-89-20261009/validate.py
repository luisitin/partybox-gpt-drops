from pathlib import Path, PurePosixPath
import json, hashlib, zipfile, stat, re, posixpath, math, datetime, subprocess

root = Path('/tmp/B19-root-checkpoint-20261009')
archive = Path('/tmp/B19-official-89-20261009/actual.zip')
prefix = 'jobs/B19-name-filter/'
head = '89ea55cbb48400e6c4d112008c2e64d55ca5d3ce'
sha = lambda b: hashlib.sha256(b).hexdigest()
observations = []
def check(label, condition):
    if not condition:
        raise AssertionError(label)
    observations.append(label)

b = archive.read_bytes()
check('actual ZIP matches official byte count', len(b) == 19236931)
check('actual ZIP matches official SHA256', sha(b) == '785aaa7226b4066ba0cffe2213318cfe07216bbd4b60f243f6338017744c7aa4')
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    check('ZIP has unique paths', len(names) == len(set(names)))
    for i in z.infolist():
        p = PurePosixPath(i.filename)
        check('safe ZIP entry: ' + i.filename, not p.is_absolute() and '..' not in p.parts and '\\' not in i.filename and not stat.S_ISLNK(i.external_attr >> 16))
    check('all ZIP member CRCs validate', z.testzip() is None)
    def data(path):
        return z.read(prefix + path)
    def obj(path):
        return json.loads(data(path))
    fresh_path = prefix + 'reports/latest/summary.json'
    check('choose unique actual fresh report, not historical results', sum(n == fresh_path for n in names) == 1)
    check('current runtime source hash', sha(data('nameFilter.ts')) == '446bdd89b9bb6fe65dcdaa2f6c7a578111034d957aeb4a9f16cc64efba5c05a0')
    check('current runner hash', sha(data('tests/run.mjs')) == '46d85ddb04f6502de84bef5f85965399874d596478147a32380b8a03917d647d')
    check('current policy retained', sha(data('data/policy.json')) == '3e3a3eab49e39e2971f02736a0bf6a189486436030ea4e58963fa2514efcd9e2')
    check('sealed reference actual bytes unchanged', sha(data('tests/blind/reference.mjs')) == '40449357a616619cc649d6b8efab2f6664a187de178511b8b0f17e28e92eea9a')
    check('original workload policy actual frozen bytes', sha(data('data/original-workload-policy.json')) == 'ac400db6c9733f6becc82df93f91cdde13563767d2b9b3883684779b28c48dc9')
    check('original corpus lock actual bytes unchanged', sha(data('data/snapshot-manifest.json')) == '46374224a6bfae76ac22ca87e77859d77d02353a26073bdfb72c91860ba79a6f')
    for path in ('nameFilter.ts', 'tests/run.mjs', 'data/policy.json', 'data/original-workload-policy.json'):
        committed = subprocess.check_output(['git', 'show', head + ':' + prefix + path], cwd=root)
        check('actual artifact equals exact committed head: ' + path, data(path) == committed)

    manifest = data('SHA256SUMS.txt')
    check('both current 1278-entry manifests byte-identical', manifest == data('reports/latest/SHA256SUMS.txt'))
    paths = []
    for row in manifest.decode().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', row)
        check('manifest row valid', match is not None)
        digest, relative = match.groups()
        path = posixpath.normpath(prefix + relative)
        check('manifest path scoped', path.startswith(prefix) or path == '.github/workflows/B19.yml')
        check('actual delivery digest: ' + relative, path in names and sha(z.read(path)) == digest)
        committed = subprocess.check_output(['git', 'show', head + ':' + path], cwd=root)
        check('actual artifact equals every exact committed delivery file: ' + relative, z.read(path) == committed)
        paths.append(path)
    check('all1278 actual delivered files checked once', len(paths) == 1278 and len(set(paths)) == 1278)
    check('all delivered files below30MB', all(len(z.read(p)) <= 30000000 for p in paths))

    lock = obj('data/snapshot-manifest.json')
    check('cache manifest matches original lock', obj('data/cache/manifest.json') == lock)
    for item in lock['outputs']:
        raw = data('data/cache/' + item['file'])
        rows = json.loads(raw)
        check('actual original corpus digest/count: ' + item['file'], sha(raw) == item['sha256'] and len(raw) == item['bytes'] and len(rows) == item['count'])
        check('actual retained corpus equals uploaded cache: ' + item['file'], raw == data('data/retained-snapshot/' + item['file']))

    s = obj('reports/latest/summary.json')
    check('actual fresh mode full,109 rows,all pass', s['mode'] == 'full' and len(s['suites']) == 109 and s['failures'] == [])
    check('fresh summary bound to actual runtime and blind bytes', s['sourceSha256'] == sha(data('nameFilter.ts')) and s['blindReferenceSha256'] == sha(data('tests/independent-unicode-20261009/reference.mjs')) and s['historicalBlindReferenceSha256'] == sha(data('tests/blind/reference.mjs')) and s['referenceSha256'] == sha(data('tests/reference.ts')))
    check('every non-latency suite passes; actual fresh failures empty', all(r['cases'] == r['passed'] for r in s['suites'] if r['name'] != 'latency-every-observed-check-under-005ms') and s['failures'] == [r for r in s['suites'] if r['cases'] != r['passed']])
    check('one acquisition and exactly36 rows each seed', sum(r.get('seed') is None for r in s['suites']) == 1 and all(sum(r.get('seed') == k for r in s['suites']) == 36 for k in (1, 2, 3)))
    native = (archive.parent / 'complete-native-job.log').read_text()
    native_rows = []
    for line in native.splitlines():
        match = re.search(r'(\{"name":.*\})', line)
        if match:
            try: native_rows.append(json.loads(match.group(1)))
            except json.JSONDecodeError: pass
    check('all actual109 fresh summary rows equal complete native job log rows', native_rows == s['suites'])
    check('full native log contains actual FINAL_SUMMARY and actual command success', 'FINAL_SUMMARY' in native and 'Process completed with exit code 1' not in native)
    run = json.loads((archive.parent / 'native-run.json').read_text())
    official = json.loads((archive.parent / 'native-artifact.json').read_text())
    check('actual native run exact head and successful attempt1', run['head_sha'] == head and run['id'] == 37880030043 and run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success')
    check('official artifact exact head/size/digest', official['id'] == 11593873496 and official['size_in_bytes'] == len(b) and official['digest'] == 'sha256:' + sha(b) and official['workflow_run']['head_sha'] == head and not official['expired'])
    check('new separately authored reference pinned to pre-exposure seal', sha(data('tests/independent-unicode-20261009/reference.mjs')) == 'a93b35e3170122b2fd0a77619eff36716c3b9fc2f4c47f3bfce1971778a76e71' and sha(data('tests/independent-unicode-20261009/seal.json')) == 'a8cded0ef5e4bf8da574184baabdfa57e9103c43981e8bc9019085ff0b9b1511')
    sealed = obj('tests/independent-unicode-20261009/seal.json')
    for item in sealed['sealed_artifacts']:
        raw = data('tests/independent-unicode-20261009/' + item['path'])
        check('actual independent sealed file matches pre-exposure byte/hash: ' + item['path'], len(raw) == item['bytes'] and sha(raw) == item['sha256'])
    check('authored public policy matches current policy exactly', data('tests/independent-unicode-20261009/policy.json') == data('data/policy.json'))
    original = subprocess.check_output(['git','show','2af0eb4535c2e270c6db9c2ff6ec23911d4fe7cd:'+prefix+'tests/run.mjs'],cwd=root).decode()
    current = data('tests/run.mjs').decode()
    for first,last in [('function rng(seed)','// Additive checks'),('const mappingCases=[]','// Supplement'),('const mutations = [','// Full command'),('const bench=benchmark(seed,','\n}\nresult.unverified')]:
        start1=original.index(first);start2=current.index(first)
        check('actual immutable original workload declaration: '+first, original[start1:original.index(last,start1)] == current[start2:current.index(last,start2)])
    recorded = []
    for seed, sink in ((1,94721),(2,93467),(3,94479)):
        rows = [r for r in s['suites'] if r.get('seed') == seed]
        byname = {r['name']:r for r in rows}
        check('unique fresh suite names seed' + str(seed), len(byname) == 36)
        expected = {'names-reviewed-corpus-policy':20000,'words-reviewed-corpus-policy':10000,'places-reviewed-corpus-policy':2000,'sealed-blind-reference-differential':43830,'regex-vs-bitset-NFA-differential':43830,'mutation-baseline-truth':43830,'repeat-call-purity':43830,'boolean-wrapper':43830,'generated-obfuscations':5000,'25-real-executed-mutations':25,'retained-original-snapshot-offline-and-corruption':8,'length-pruned-matcher-blind-boundaries':24873,'additional-given-names-and-exception-bypass':30,'original-workload-policy-and-counts':6,'failure-suggestions-map-and-frozen':5,'latency-every-observed-check-under-005ms':10000,'new-independent-reference-seal-and-input-identities':13,'expanded-bidi-surrogate-and-unknown-category-contract':92568,'four-additional-real-Unicode-contract-mutations':4}
        check('all original and supplemental required counts seed' + str(seed), all(byname[n]['cases'] == count and byname[n]['passed'] == (count) for n,count in expected.items()))
        check('actual integrity1278 seed' + str(seed), byname['delivery-file-size-and-checksums']['files'] == 1278 and byname['delivery-file-size-and-checksums']['checked'] == 1278 and byname['delivery-file-size-and-checksums']['failures'] == [])
        check('original workload guard fields seed' + str(seed), byname['original-workload-policy-and-counts']['fixedCases'] == 459 and byname['original-workload-policy-and-counts']['fullCases'] == 43830 and byname['original-workload-policy-and-counts']['benchmarkPositiveInputs'] == 48)
        mutants = obj('reports/latest/mutations-seed' + str(seed) + '.json')
        check('actual25 executable mutant receipts seed' + str(seed), len(mutants) == 25 and len({m['id'] for m in mutants}) == 25 and all(m['seed'] == seed and m['killed'] and m['cases'] == 43830 and m['excludedBaselineFailures'] == 0 and m['disagreements'] > 0 and m['witness'] is not None and re.fullmatch('[0-9a-f]{64}',m['mutantSha256']) for m in mutants))
        additional = obj('reports/latest/unicode-mutations-seed' + str(seed) + '.json')
        check('actual four additional Unicode mutants seed'+str(seed), len(additional)==4 and {m['id'] for m in additional}=={'U-061c','U-200e','U-200f','U-unknown'} and all(m['seed']==seed and m['killed'] and m['cases']==30856 and m['disagreements']>0 and m['witness'] is not None and re.fullmatch('[0-9a-f]{64}',m['mutantSha256']) for m in additional))
        obf = [json.loads(line) for line in data('reports/latest/obfuscations-seed' + str(seed) + '.jsonl').decode().splitlines()]
        check('actual5000 generated fixtures seed' + str(seed), len(obf) == 5000 and len({r['input'] for r in obf}) == 5000 and all(r['expected'] == 'blocked' and len(r['input']) <= 16 for r in obf))
        check('all63 policy terms covered seed' + str(seed), {r['term'] for r in obf} == set(obj('data/policy.json')['terms']))
        bench = obj('reports/latest/benchmark-seed' + str(seed) + '.json')
        row = byname['latency-every-observed-check-under-005ms']
        check('actual benchmark equals every corresponding summary field seed' + str(seed), all(row[k] == value for k,value in bench.items()))
        check('recorded actual literal0/0/0 gate and original seeded sink seed' + str(seed), bench['calls'] == 10000 and bench['sink'] == sink and bench['over005Ms'] == 0 and len(bench['outliers']) == bench['over005Ms'] and row['passed'] == 10000-bench['over005Ms'] and all(0 <= item['index'] < 10000 and item['timeMs'] > 0.05 and math.isfinite(item['timeMs']) for item in bench['outliers']) and 0 <= bench['maxMs'] <= 0.05 and all(math.isfinite(bench[k]) and bench[k] >= 0 for k in ('meanMs','p50Ms','p99Ms','maxMs')))
        recorded.append({'seed':seed,'calls':bench['calls'],'recordedMaximumMs':bench['maxMs'],'recordedOutliers':bench['over005Ms'],'originalSink':bench['sink']})
    receipt = {'kind':'actual-full-green-hosted-artifact-independent-structural-and-byte-validation','head':head,'runId':37880030043,'jobId':113657351539,'artifactId':11593873496,'actualZipBytes':len(b),'actualZipSha256':sha(b),'validatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualFreshSummaryPath':fresh_path,'sourceSha256':s['sourceSha256'],'freshSuiteRowsExecuted':109,'freshSuiteRowsPassed':109,'literalAcceptancePassed':True,'actualHostedLiteralGatePassVerified':True,'actualDeliveredHashesChecked':1278,'originalFullCasesPerSeed':43830,'recordedBenchmarks':recorded,'checksPassed':len(observations),'scope':'Actual green artifact bytes and all fresh receipts are independently bound to exact89ea55 source. The actual full hosted source-bound literal gates pass0/0/0; all109 rows pass. Historical 8d failure1/0/0 remains retained. This verifies one genuine passing hosted observation, preserves the old-source required after-green13/5/10 as historical. This three-control-corrected source restarts KEEP at zero and needs its actual once-after-green original full run. Recorded summaries are verified as recorded, not claimed to contain or recompute every individual timed call. This does not erase the unchanged runtime source first local12/9/2 or the single binding6a after-green13/5/10 failure, authorize unchanged lottery retries, finish KEEP, establish a cause or prove a hardware-independent bound.'}
    (archive.parent/'independent-hosted-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))
