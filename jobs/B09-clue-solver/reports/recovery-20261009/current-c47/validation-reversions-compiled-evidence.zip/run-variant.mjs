import assert from 'node:assert/strict';
import{pathToFileURL}from'node:url';
process.env.B09_IMPORT_ONLY='1';
const{smoke}=await import(pathToFileURL('/tmp/gpt-drops-B09-audit-20261009/jobs/B09-clue-solver/test.mjs'));
const{solveClue}=await import(pathToFileURL(process.argv[2]));
const records=[];
for(const seed of[1,2,3]){let error;try{smoke(solveClue,seed);}catch(e){error=e;}assert(error,'validation regression escaped detection');assert.match(error.message,/independent status/);records.push({seed,killed:true,actualFailure:error.message});}
console.log(JSON.stringify({id:process.argv[3],strictCompiledVariantActuallyExecuted:true,records}));
