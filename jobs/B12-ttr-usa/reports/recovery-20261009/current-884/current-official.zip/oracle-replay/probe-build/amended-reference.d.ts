/** Blind B12 oracle: independently authored from the original prompt/public contract. */
export type Card = 'pink' | 'white' | 'blue' | 'yellow' | 'orange' | 'black' | 'red' | 'green' | 'locomotive';
export interface Route {
    readonly id: string;
    readonly a: string;
    readonly b: string;
    readonly length: number;
    readonly color: Exclude<Card, 'locomotive'> | 'gray';
    readonly parallelGroup?: string;
}
export interface Ticket {
    readonly id: string;
    readonly a: string;
    readonly b: string;
    readonly points: number;
}
export interface Player {
    readonly id: string;
    readonly cards: Readonly<Record<Card, number>>;
    readonly trainsRemaining: number;
    readonly ticketIds: readonly string[];
}
export interface Game {
    readonly playerCount: number;
    readonly players: readonly Player[];
    readonly claims: Readonly<Record<string, string>>;
}
export interface Claim {
    readonly routeId: string;
    readonly playerId: string;
    readonly cards: readonly Card[];
}
export interface Score {
    readonly playerId: string;
    readonly routePoints: number;
    readonly ticketPoints: number;
    readonly longestLength: number;
    readonly longestBonus: number;
    readonly total: number;
    readonly completedTicketIds: readonly string[];
}
export declare function canClaim(routes: readonly Route[], game: Game, claim: Claim): boolean;
export declare function applyClaim(routes: readonly Route[], game: Game, claim: Claim): Game;
export declare function ticketComplete(routes: readonly Route[], ownedIds: readonly string[], ticket: Ticket): boolean;
export declare function longestTrail(routes: readonly Route[], ownedIds: readonly string[]): number;
export declare function scoreGame(routes: readonly Route[], tickets: readonly Ticket[], game: Game): readonly Score[];
export declare function seeded(seed: number): () => number;
